export default function About() {
    return (
    <div className="Main">
        О компании
    </div>
    )
}